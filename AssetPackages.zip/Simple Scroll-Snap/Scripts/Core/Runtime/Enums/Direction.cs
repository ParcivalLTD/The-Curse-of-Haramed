// Simple Scroll-Snap - https://assetstore.unity.com/packages/tools/gui/simple-scroll-snap-140884
// Copyright (c) Daniel Lochner

namespace DanielLochner.Assets.SimpleScrollSnap
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }
}